import {createContext} from "react";
export const ContractContext  = createContext(null);