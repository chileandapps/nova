import React from "react";
import styled from "styled-components";

const ModalContainer = styled.div`
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.7);
  position: fixed;
  display: flex;
  justify-content: center;
  align-items: center;

  & .modal-wrapper {
    width: 800px;
    height: 500px;
    color: #000;
    padding: 10px;
    position: relative;
    z-index: 9;
  }

  & .modal-content {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    line-height: 1.8;
    color: white;
  }
`;
const Modal = ({ showModal, setShowModal, hash }) => {
  const close = () => {
    setShowModal((prev) => !prev);
  };
  return (
    <>
      {showModal ? (
        <ModalContainer onClick={close}>
          <div className="modal-wrapper">
            <div className="modal-content">
              <h3>You can track your transaction below: </h3>
              <p>{hash}</p>
            </div>
          </div>
        </ModalContainer>
      ) : null}
    </>
  );
};

export default Modal;
