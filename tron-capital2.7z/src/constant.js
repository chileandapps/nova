export const CONTRACT_ADDRESS = "TLzYbJfnNiR553sKsdWbTK1qzfpvTN4ccA";
export const TRX_UNIT = 1000000;
export const LOG_COLOR = 'background: #222; color: #bada55';