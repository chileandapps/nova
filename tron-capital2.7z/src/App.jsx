import "./assets/App.css";
import { useEffect, useState } from "react";
import { getTronWeb, getContract, getWalletInfo } from "./tronWeb";
import { LOG_COLOR } from "./constant";
import { Contract } from "./contract.js";
import { Dashboard } from "./components/Dashboard";
import Modal from "./components/Modal";
import Table from "./components/Table";
import { Home } from "./components/Home";

import {
  walletInfoInitialState,
  contractGlobalInfoInitialState,
  contractUserInfoInitialState,
} from "./store/initialState";
import { ContractContext } from "./store/context";
import Navbar from "./components/Navbar";
import { Switch, Route } from "react-router-dom";

function App() {
  const [reload, setReload] = useState(false);
  const [contract, setContract] = useState(null);
  const [walletInfo, setWalletInfo] = useState(walletInfoInitialState);
  const [contractUser, setContractUser] = useState(
    contractUserInfoInitialState
  );
  const [contractGlobal, setContractGlobal] = useState(
    contractGlobalInfoInitialState
  );
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    console.log("%c useEffect", LOG_COLOR);
    fetchTronWeb()
      .then(() => {

        fetchData();
      })
      .catch((err) => {
        console.log(err)
        alert('install Tronlink');
      });
  }, [reload]);

  const fetchTronWeb = async () => {
    //Get tronWeb from window
    await getTronWeb();
  };

  const fetchData = async () => {
    try {
      const walletInfo = await getWalletInfo();
      const contract = new Contract(await getContract(), walletInfo.address);
      setContract(contract);
      await contract.Initialize();
      const referalLink = contract.getReferalLink();

      //Events
      contract.setWriteActionsHandler(() => {
        //todo: show popup
        setReload(!reload);
      });

      setWalletInfo(walletInfo);
      setContractGlobal(await contract.getContractGlobalInfo());

      const data = await contract.getContractUserInfo();
      setContractUser(data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="App">
      <ContractContext.Provider value={contract}>
        <div>
          <Modal
            showModal={showModal}
            setShowModal={setShowModal}
            hash={"1237asd"}
          />
          <Navbar walletInfo={walletInfo} />

          {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
          <Switch>
            <Route path="/about"></Route>
            <Route path="/dapp">
              <Dashboard
                contractGlobal={contractGlobal}
                contractUser={contractUser}
                trxBalance={walletInfo.balance}
              />
              <Table contractUser={contractUser} />
            </Route>
            <Route path="/">
              <Home />
            </Route>
          </Switch>
        </div>
      </ContractContext.Provider>
    </div>
  );
}

export default App;
